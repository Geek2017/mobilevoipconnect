'use strict';

app.controller('MorrisCtrl', function($scope){
  $scope.barData = [
        { y: "2009", a: 175,  b: 165, c: 160, d: 140},
        { y: "2010", a: 150,  b: 140, c: 120, d: 110 },
        { y: "2011", a: 175,  b: 165, c: 60, d: 190 },
        { y: "2012", a: 60, b: 190, c: 60, d: 190 }
    ];

});