'use strict';

/* Controllers */

  // Form controller
app.controller('FormValidationCtrl', ['$scope', function($scope) {
    $scope.notBlackListed = function(value) {
      var blacklist = ['bad@domain.com','verybad@domain.com'];
      return blacklist.indexOf(value) === -1;
    }
}]);
