'use strict';

app.controller('CounttoCtrl', function($scope){

	$scope.countTo = 5343;
    	$scope.countFrom = 1001;
	
	$scope.countTo_facebook = 143;
    	$scope.countFrom_facebook = 0;

	$scope.countTo_twitter = 3454;
    	$scope.countFrom_twitter = 0;

	$scope.countTo_googleplus = 523;
    	$scope.countFrom_googleplus = 0;

	$scope.countTo_dribbble = 2523;
    	$scope.countFrom_dribbble = 0;

	$scope.countTo_linkedin = 3223;
    	$scope.countFrom_linkedin = 0;

	$scope.countTo_youtube = 1223;
    	$scope.countFrom_youtube = 0;

	$scope.countTo_skype = 3229;
    	$scope.countFrom_skype = 0;

	$scope.countTo_flickr = 1629;
    	$scope.countFrom_flickr = 0;
});

